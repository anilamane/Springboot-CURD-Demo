package com.example.demo1.student;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDate;
import java.time.Month;
import java.util.List;

@Configuration
public class StudentConfig {
    @Bean
    CommandLineRunner commandLineRunner(StudentRepository repository){
        return args -> {
            Student krisha  = new Student(1L,
                    "Krishna",
                    "krishna.gokul@gmail.com",
                    LocalDate.of(300, Month.JANUARY,1)
            );

            Student arjun = new Student(2L,
                    "arjuna",
                    "arjuna.geeta@gmail.com",
                    LocalDate.of(400, Month.FEBRUARY,2)
            );

            Student karna = new Student(3L,
                    "karna",
                    "karna.geeta@gmail.com",
                    LocalDate.of(500, Month.MARCH,3)
            );

            repository.saveAll(
                    List.of(krisha,arjun,karna)
            );

        };
    }
}
